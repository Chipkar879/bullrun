import { NextResponse } from 'next/server';
import { ASSETS, ASSET_BY_SYM } from '@/lib/catalog';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

// Simulated prices for every asset in lib/catalog.js. All names and prices are invented.
// Prices are a pure function of (asset, time), so every device sees the same numbers.
// Indices and funds are weighted baskets of the stocks listed in the catalog.

const DEFAULT_VOL = 0.0016;

const SEED = 'bullrun-v1';   // change this text to reshuffle every price path
const TICK_MS = 15000;       // one new price every 15 seconds, same for everyone
const PHI = 0.998;           // pull toward base (closer to 1 = slower pull)
const WINDOW = 2500;         // ticks of memory (~10 hours)
const TICKS_PER_MIN = 4;
const HISTORY_POINTS = 60;   // one point per minute, last hour
const TICKS_PER_DAY = 5760;

function hashString(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// Deterministic uniform value in (0,1) for (seed, n).
function noise(seed, n) {
  let h = (seed ^ Math.imul(n, 0x9e3779b1)) >>> 0;
  h = Math.imul(h ^ (h >>> 16), 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  h ^= h >>> 16;
  return ((h >>> 0) + 0.5) / 4294967296;
}

// Deterministic standard-normal shock for a given tick (Box-Muller).
function shock(seed, tick) {
  const u1 = noise(seed, tick * 2);
  const u2 = noise(seed, tick * 2 + 1);
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

// Log-deviation from base for each tick in the window ending at endTick.
function walk(seed, sigma, endTick) {
  const out = [];
  let x = 0;
  for (let tick = endTick - WINDOW + 1; tick <= endTick; tick += 1) {
    x = PHI * x + sigma * shock(seed, tick);
    out.push(x);
  }
  return out;
}

const toPrice = (base, rel) => Number((base * rel).toFixed(2));

// Weighted average of the constituents' price relatives (price / base price).
function basketRelative(basket, relOf) {
  let total = 0;
  let weights = 0;
  basket.forEach(([sym, weight]) => {
    total += weight * relOf(sym);
    weights += weight;
  });
  return weights > 0 ? total / weights : 1;
}

function basketOf(asset) {
  if (asset.basket) return asset.basket;
  if (asset.tracks) return ASSET_BY_SYM[asset.tracks]?.basket || [];
  return null;
}

function buildPrices(currentTick) {
  // 1. Random walk for every asset that has its own price.
  const walks = {};
  const dayAgo = {};
  ASSETS.forEach((asset) => {
    if (basketOf(asset)) return;
    const seed = hashString(`${SEED}:${asset.sym}`);
    const sigma = asset.vol ?? DEFAULT_VOL;
    walks[asset.sym] = walk(seed, sigma, currentTick);
    const old = walk(seed, sigma, currentTick - TICKS_PER_DAY);
    dayAgo[asset.sym] = old[old.length - 1];
  });

  // 2. Price relative of one walked asset at a given point in its series.
  const lastIndex = WINDOW - 1;

  return ASSETS.map((asset) => {
    const basket = basketOf(asset);

    const relAt = (back) => {
      if (!basket) return Math.exp(walks[asset.sym][lastIndex - back]);
      return basketRelative(basket, (sym) => Math.exp(walks[sym][lastIndex - back]));
    };
    const relDayAgo = () => {
      if (!basket) return Math.exp(dayAgo[asset.sym]);
      return basketRelative(basket, (sym) => Math.exp(dayAgo[sym]));
    };

    const history = [];
    for (let i = HISTORY_POINTS - 1; i >= 0; i -= 1) {
      history.push({
        time: Math.floor(((currentTick - i * TICKS_PER_MIN) * TICK_MS) / 1000),
        close: toPrice(asset.base, relAt(i * TICKS_PER_MIN)),
      });
    }

    const price = toPrice(asset.base, relAt(0));
    const before = toPrice(asset.base, relDayAgo());
    const change = before > 0 ? ((price - before) / before) * 100 : 0;

    return {
      symbol: asset.sym,
      price,
      changePct: `${change > 0 ? '+' : ''}${change.toFixed(2)}%`,
      history,
    };
  });
}

// Everyone gets the same numbers within a tick, so compute them once per tick.
let cache = { tick: -1, prices: null };

export async function GET() {
  try {
    const now = Date.now();
    const currentTick = Math.floor(now / TICK_MS);

    if (cache.tick !== currentTick) {
      cache = { tick: currentTick, prices: buildPrices(currentTick) };
    }

    return NextResponse.json(
      {
        mode: 'prototype',
        isRealHistoricalData: false,
        dataLabel: 'SIMULATED MARKET DATA',
        marketOpen: true,
        indiaTime: new Date(now).toLocaleTimeString('en-GB', { timeZone: 'Asia/Kolkata' }),
        sessionDate: new Date(now).toISOString().slice(0, 10),
        prices: cache.prices,
      },
      { headers: { 'Cache-Control': 'no-store, max-age=0' } }
    );
  } catch (error) {
    console.error('Price simulation API error:', error);
    return NextResponse.json(
      { error: 'Could not generate simulated prices.' },
      { status: 500 }
    );
  }
}